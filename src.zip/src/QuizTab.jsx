// src/QuizTab.jsx
import React from 'react';

export default function QuizTab() {
  return (
    <div className="flex-1 p-6 bg-white rounded shadow text-gray-600">
      <p>SmartQuiz is coming soon! Stay tuned.</p>
    </div>
  );
}
